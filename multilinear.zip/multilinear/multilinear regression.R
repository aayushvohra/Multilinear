#######################STARTUP_50##########################
library(data.table)

startup_50 <- fread("G:/practical data science/Assignments/multilinear/50_Startups.csv")
# Getting Summary of data
summary(startup_50)
# Variance
var(startup_50$`R&D Spend`)
var(startup_50$Administration)
var(startup_50$`Marketing Spend`)
var(startup_50$Profit)
# Standard Deviation
sd(startup_50$`R&D Spend`)
sd(startup_50$Administration)
sd(startup_50$`Marketing Spend`)
sd(startup_50$Profit)
unique(startup_50$State)

startup_50 <- cbind(startup_50,ifelse(startup_50$State=="New York",1,0), ifelse(startup_50$State=="California",1,0),  ifelse(startup_50$State=="Florida",1,0))


# Renaming the column
setnames(startup_50, 'V2','New York')
setnames(startup_50, 'V3','California')
setnames(startup_50, 'V4','Florida')

# Ploting the data on scatter plot
# plot(startup_50) # This line give us error because we have a texual values state
plot(startup_50[,-c('State')]) # In this plot we are plotting dummy which seems no relative
plot(startup_50[,-c('State','New York','California','Florida')]) # After removing state and dummy columns
#install.packages("corpcor")
library(corpcor)
cor2pcor(cor(startup_50[,-c('State','New York','California','Florida')]))
colnames(startup_50)
Profit_Model <- lm(Profit~`R&D Spend`+Administration+`Marketing Spend`, data = startup_50)

summary(Profit_Model)

library(car)
influenceIndexPlot(Profit_Model)
influencePlot(Profit_Model,id.n=3)
Profit_Model_Inf <- lm(Profit~`R&D Spend`+Administration+`Marketing Spend`, data = startup_50[-c(50,49),])

summary(Profit_Model_Inf)

Profit_Model <- lm(Profit~`R&D Spend`+Administration+`Marketing Spend`, data = startup_50)
class(startup_50$`Marketing Spend`)
vif(Profit_Model)
summary(Profit_Model)
avPlots(Profit_Model)

Profit_Model_Revised <- lm(Profit~`R&D Spend`+Administration+`Marketing Spend`+`New York`+California+Florida, data = startup_50)

library(MASS)

stepAIC(Profit_Model_Revised)

Profit_Model_Final <- lm(Profit~`R&D Spend`+`Marketing Spend`, data = startup_50)

summary(Profit_Model_Final)

plot(Profit_Model_Final)
qqPlot(Profit_Model_Final, id.n=5)

#########################Predict sales of the computer#########################
# Read dats from file
library(data.table)
Computer_Data <- fread("G:/practical data science/Assignments/multilinear/Computer_Data.csv")

colnames(Computer_Data)
str(Computer_Data)
# Creating Dummy Variable

Computer_Data$cd_dummy1 <- ifelse(Computer_Data$cd=="yes",1,0)
Computer_Data$multi_dummy1 <- ifelse(Computer_Data$multi=='yes',1,0)
Computer_Data$premium_dummy1 <- ifelse(Computer_Data$premium=='yes',1,0)

Computer_Data$cd_dummy2 <- ifelse(Computer_Data$cd=='no',1,0)
Computer_Data$multi_dummy2 <- ifelse(Computer_Data$multi=='no',1,0)
Computer_Data$premium_dummy2 <- ifelse(Computer_Data$premium=='no',1,0)

comp_data <- (Computer_Data[,-c('V1','cd','multi','premium')])

str(comp_data)
summary(comp_data)
colnames(comp_data)
attach(comp_data)
comp_model <- lm(price ~ speed+hd+ram+screen+ads+trend+cd_dummy1+multi_dummy1+premium_dummy1, data = comp_data)

summary(comp_model)

influenceIndexPlot(comp_model, id.n=3)
avPlots(comp_model)
library(MASS)
vif(comp_model)
stepAIC(comp_model)
comp_model_final <- lm(price ~ speed+hd+ram+screen+ads+trend+cd_dummy1+multi_dummy1+premium_dummy1, data = comp_data)


summary(comp_model_final)
#############################Toyato corrlaa#########################
ToyotaCorolla <- fread("G:/practical data science/Assignments/multilinear/ToyotaCorolla.csv")

setkey(ToyotaCorolla, Id)

Corolla <- ToyotaCorolla[, c('Price','Age_08_04','KM','HP','cc','Doors','Gears','Quarterly_Tax','Weight')]

Corolla_Model <- lm(Price ~ Age_08_04+KM+HP+cc+Doors+Gears+Quarterly_Tax+Weight,data = Corolla)

summary(Corolla_Model)
vif(Corolla_Model)
avPlots(Corolla_Model)
stepAIC(Corolla_Model)
Corolla_Model_final <- lm(Price ~ Age_08_04+KM+HP+log(cc)+Gears+Quarterly_Tax+Weight,data = Corolla)

summary(Corolla_Model_final)

