# -*- coding: utf-8 -*-
"""
Created on Tue Oct 27 22:21:18 2020

@author: AAYUSH VOHRA
"""
import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt

price_car=pd.read_csv("G:/practical data science/Assignments/multilinear/ToyotaCorolla.csv", encoding ="windows-1252")
price_car.head()
price_car.shape
price_car.columns
price_car.info()
price_car.describe()
%matplotlib inline
price_car['Price'].plot.hist()
price_car.plot.scatter(x='KM', y='HP', c='Price', cmap='bwr', s=200)
price_car.groupby("Mfg_Year").count()['Id']
price_car.groupby(['Mfg_Year', 'Fuel_Type']).count()['Id']
import seaborn as sns
effect_on_price= ['Price','Age_08_04', 'KM', "HP", 'Cylinders', 'Gears']
sns.pairplot(price_car[effect_on_price])
import statsmodels.formula.api as smf #for regression model
ml1=smf.ols('Price~Age_08_04+KM+HP+Cylinders+Gears', data=price_car).fit() # regression model
ml1.params
ml1.summary()
import statsmodels.api as sm
sm.graphics.influence_plot(ml1)
sm.graphics.plot_partregress_grid(ml1)
