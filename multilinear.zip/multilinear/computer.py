# -*- coding: utf-8 -*-
"""
Created on Tue Oct 27 07:56:36 2020

@author: AAYUSH VOHRA
"""
import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
price_comp=pd.read_csv("G:/practical data science/Assignments/lasso/Computer_Data.csv")
price_comp.head()
price_comp.drop(['cd', 'multi', 'premium'], axis=1).head()
price_comp.corr(method ='pearson')
sns.pairplot(price_comp, vars=["price", "speed","hd", "ram"])
import statsmodels.formula.api as smf
model_profit=smf.ols('price ~ speed + hd + ram + screen + ads + trend', data=price_comp).fit() # regression model
model_profit.summary()
import statsmodels.api as sm
sm.graphics.influence_plot(model_profit)
sm.graphics.plot_partregress_grid(model_profit)
